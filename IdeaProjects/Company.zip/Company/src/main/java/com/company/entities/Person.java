package com.company.entities;

public class Person {
    String initials;
    int age;
    String gender;
    String phoneNumber;

    public Person(String initials, int age, String gender, String phoneNumber) {
        this.initials = initials;
        this.age = age;
        this.gender = gender;
        this.phoneNumber = phoneNumber;
    }

}
